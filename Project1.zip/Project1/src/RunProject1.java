package src;
/**
 * Driver program
 * 
 * 
 * @author Sebastian Hanna
 */
public class RunProject1 {
    public static void main(String[] args){
        new EventOrganizer().run();
    }
}
